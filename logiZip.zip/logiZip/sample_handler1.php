﻿<?php
  if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
  class logic_hook_one
  {
  	function method_one($bean, $event, $arguments)
  	{
		$GLOBALS['log']->fatal("RUNNING before_save_method");
  	}
  }
?>
