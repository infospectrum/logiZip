﻿<?php
  if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
  class logic_hook_two
  {
   //Using before and after save in same class
   //logiZip shows a warning and creates a manifest that should be editted accordingly

	function method_one($bean, $event, $arguments)
  	{
		$GLOBALS['log']->fatal("RUNNING before_save_method");
  	}

  	function method_two($bean, $event, $arguments)
  	{
		$GLOBALS['log']->fatal("RUNNING after_save_method");
  	}
  }
?>
