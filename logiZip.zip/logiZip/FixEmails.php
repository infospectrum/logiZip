<?php
// Updates module Accounts records with email addresses stored in the googleplus field
// More info: http://www.sugarforge.org/projects/logizip/
$job_strings[] = 'FixEmails';

function FixEmails()
{
	require_once('data/BeanFactory.php');
	require_once('data/SugarBean.php');
	require_once 'include/SugarEmailAddress/SugarEmailAddress.php'; 
	global $sugar_config;
	$GLOBALS['log']->fatal('Starting FixEmails Scheduler Job');	
	
	  $pd = BeanFactory::getBean('Accounts');
	  $where = "accounts.googleplus is not null and accounts.googleplus <> ''";
	  $pd_list = $pd->get_full_list("",$where,true); 
	  if (isset($pd_list)) 
	  {	
		  $counts=count($pd_list);		  
		  for($i = 0;$i < $counts;$i++) 
		  { 
			  $acct = $pd_list[$i];
			  if (! isset($acct) || $acct === FALSE) 
			  {
				$GLOBALS['log']->fatal("Failed to get Accounts");
			  }
			  else
			  {	
				$nm = $acct->name;				
				$sea = new SugarEmailAddress();
				// Add a primary email address from google plus field
				$emailaddress = $acct->googleplus;
				$sea->addAddress($emailaddress, true);				
				// Associate the email address with the Accounts record
				$sea->save($acct->id, "Accounts"); 
				$GLOBALS['log']->fatal("Updated Email Address {$emailaddress} for {$nm}");
			  }
		   } // end for	
		   $GLOBALS['log']->fatal("Found {$counts} Email Addresses");
		   
	  }
	  else 
	   $GLOBALS['log']->fatal("Failed to find any Email Addresses");
	  return true;	
}