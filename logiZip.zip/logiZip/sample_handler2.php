﻿<?php
  if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
  class logic_hook_two
  {
  	function method_two($bean, $event, $arguments)
  	{
		$GLOBALS['log']->fatal("RUNNING after_save_method");
  	}
  }
?>
